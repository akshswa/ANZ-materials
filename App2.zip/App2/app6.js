var ford = new Backbone.Model({
    type: 'car',
    color: 'blue'
});
// trigger this  on ford object for  every propery
ford.on('change',function(){
    console.log('some thing changed');
});
// occures only when color propery changed on ford
ford.on('change:color',function(){
    console.log('.... Color is being changed');
});

ford.set('type','Truck');
ford.set('color','White');
ford.set('name','Praveen');

