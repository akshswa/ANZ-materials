
var Vehicle = Backbone.Model.extend({
    name:'Praveen',

    initialize: function () {
        //console.log('Vehicle class is started with id '+this.cid);
        console.log('Name is '+this.name);
    },
    getName:function(){
        console.log('Second: Name: '+name);
    }


});
var car1 = new Vehicle();
car1:{
name:'James';
}
car1.getName();
var car2 = new Vehicle();

car2:{
    name='Pragathi';
}


car2.getName();

var MyApp = Backbone.View.extend({

  initialize: function () {
       
        console.log('MyApp started');
        var car = new Vehicle();
        this.sayHello();
    },

    el: '#d1',

    sayHello: function () {
        $('#d2').append('<h2>New Data from Backbonne</h2>');
        this.$el.html('<h2>Welcome to Backbone</h2>');
    }
});

var obj = new MyApp();

