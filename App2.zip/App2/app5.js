// Inheritance
var A = Backbone.Model.extend({
    empName:'James',
    initialize: function () {
        console.log('.. initialized A');
    },
    asString: function () {

        return JSON.stringify(this.toJSON());
    }
});

var B = A.extend({
    initialize:function(){
        console.log('- in B Constructor: EmpName: '+this.empName);
    },

    dispB:function(){
        console.log('-- B: One: '+this.get('one'));
        console.log('-- B: Two: '+this.get('two'));
    }
});

var a = new A({
    one: '1',
    two: '2'
});

console.log(a.asString());
var b = new B({
    three: '3'
});
b .set('one','1 Modified');
b .set('two','2 Modified');

b.dispB(); // doesnot print one and two's values (use get too get values)

console.log(b.asString());

console.log(b instanceof B); // true
console.log(b instanceof A); // true
console.log(b instanceof Backbone.Model); // true
console.log(a instanceof B); // false


