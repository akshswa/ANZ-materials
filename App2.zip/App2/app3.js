var Vehicle=Backbone.Model.extend({
dump:function(){
    console.log(JSON.stringify(this.toJSON()));
},
myContent:function(){
return this;
}

});

// set the property in the v constructor
var v=new Vehicle({
    type:'car'
});

var ford=new Vehicle({
    type:'car'
});

// set a single prperty
v.set('color','blue');  // --> setter

// set multiple values
v.set({
description:"<h2>Red Color top varient</h2>",
weight:765
});

// v.dump();

// $('body').append(v.get('description'));  
// //$('body').append(v.escape('description'));  
// $('#d1').append(v.myContent().get('color'));
//console.log(v.myContent().get());
// console.log(ford.has('type'));
// console.log(ford.has('year'));
console.log(ford.id); // undefined
console.log(ford.cid); // c2
console.log(ford.isNew()); // true