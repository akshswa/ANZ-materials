

$(document).ready(function () {

    var allPosts = [];

    var apiUrl = "http://localhost:3000/api/posts";

    //----------------------------------------------------------------

    // load all posts from server-side thru XHR calls
    $.ajax(apiUrl, {
        method: 'GET',
        success: function (posts) {
            allPosts = posts;
            renderAllPosts();
        }
    });

    //-----------------------------------------------------------------


    //-----------------------------------------------------------------

    // render all posts
    var $allPostsDiv = $('#all-posts');

    function renderAllPosts() {
        $allPostsDiv.children().remove();
        allPosts.reverse().forEach(function (post, idx) {
            var postTemplate = `
                <div class="list-group-item">
                    <div class="alert alert-info" data-id="${post.id}">
                        Name : <span class="badge"> ${post.name} </span> 
                               <span class="glyphicon glyphicon-trash pull-right" style="cursor:pointer"></span> <hr/>
                        <p>${post.comment}</p>
                    </div>      
                </div>
            `;
            $allPostsDiv.append($(postTemplate));
        });
    }

    //-----------------------------------------------------------------

    $('#all-posts').on('click', '.glyphicon-trash', function () {
        var id = $(this).closest('div').data('id');

        $.ajax(apiUrl + "/" + id, {
            method: 'DELETE',
            success: function () {
                allPosts = allPosts.reverse().filter(function (post) {
                    return post.id !== id;
                });
                renderAllPosts();
            }
        });
    })

    //-----------------------------------------------------------------

    $('#post-form').on('submit', function (e) {

        e.preventDefault();

        var $nameField = $('#post-form-name', $(this));
        var $commentField = $('#post-form-comment', $(this));

        //----------------------------------------------------------------

        // validate

        // var name=$nameField.val();
        // if(!name){
        //     //$nameField.focus().closest('div').addClass('has-error');
        //     $nameField.focus()
        //               .after($('<div class="help-block"> Name is Required </div>'))
        //               .closest('div')
        //               .addClass('has-error');
        //     return;
        // }

        //-----------------------------------------------------------------

        var newPost = {
            //id:Math.floor(Math.random()*1000),
            name: $nameField.val(),
            comment: $commentField.val()
        }

        $.ajax(apiUrl, {
            method: 'POST',
            contentType: "application/json",
            data: JSON.stringify(newPost),
            success: function (post) {
                allPosts.push(newPost);
                renderAllPosts();
            }
        });


        $nameField.val('').focus();
        $commentField.val('');

        //-----------------------------------------------------------------

    });


});